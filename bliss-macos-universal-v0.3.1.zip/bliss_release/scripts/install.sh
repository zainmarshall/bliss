#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_BIN="/usr/local/bin"
SHARE_DIR="/usr/local/share/bliss"

echo "[bliss] install: starting"

# --- CLI binaries (skip build if prebuilt exist in release) ---
if [[ -f "${ROOT_DIR}/build/bliss" && -f "${ROOT_DIR}/build/blissd" && -f "${ROOT_DIR}/build/blissroot" ]]; then
  echo "[bliss] install: using prebuilt CLI binaries"
else
  echo "[bliss] install: building CLI from source"
  cmake -S "${ROOT_DIR}" -B "${ROOT_DIR}/build" >/dev/null 2>&1
  cmake --build "${ROOT_DIR}/build"
fi

# --- GUI app (skip swiftc if prebuilt .app exists in release) ---
PREBUILT_APP="${ROOT_DIR}/gui/build/BlissGUI.app"
GUI_BUILD_DIR="${ROOT_DIR}/gui/build_install"
GUI_APP_BUNDLE="${GUI_BUILD_DIR}/BlissGUI.app"
GUI_APP_CONTENTS="${GUI_APP_BUNDLE}/Contents"
GUI_APP_MACOS="${GUI_APP_CONTENTS}/MacOS"
GUI_APP_RESOURCES="${GUI_APP_CONTENTS}/Resources"
GUI_APP_BIN="${GUI_APP_MACOS}/BlissGUI"

if [[ -f "${PREBUILT_APP}/Contents/MacOS/BlissGUI" ]]; then
  echo "[bliss] install: using prebuilt GUI"
  rm -rf "${GUI_APP_BUNDLE}"
  mkdir -p "${GUI_BUILD_DIR}"
  cp -R "${PREBUILT_APP}" "${GUI_APP_BUNDLE}"
else
  echo "[bliss] install: building GUI from source"
  mkdir -p "${GUI_APP_MACOS}" "${GUI_APP_RESOURCES}/problems" "${GUI_APP_RESOURCES}/quotes"
  cp -f "${ROOT_DIR}/problems/"*.json "${GUI_APP_RESOURCES}/problems/" 2>/dev/null || true
  cp -f "${ROOT_DIR}/quotes/"*.txt "${GUI_APP_RESOURCES}/quotes/" 2>/dev/null || true
  cp -f "${ROOT_DIR}/gui/AppIcon.icns" "${GUI_APP_RESOURCES}/AppIcon.icns" 2>/dev/null || true
  /usr/bin/swiftc -parse-as-library -module-cache-path /tmp/bliss_module_cache \
    -framework SwiftUI -framework AppKit -framework UserNotifications \
    "${ROOT_DIR}/gui/"*.swift -o "${GUI_APP_BIN}"
  cat > "${GUI_APP_CONTENTS}/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleDevelopmentRegion</key><string>en</string>
  <key>CFBundleExecutable</key><string>BlissGUI</string>
  <key>CFBundleIdentifier</key><string>com.bliss.gui</string>
  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
  <key>CFBundleName</key><string>BlissGUI</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>0.3.1</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>CFBundleURLTypes</key>
  <array><dict>
    <key>CFBundleURLName</key><string>com.bliss.gui</string>
    <key>CFBundleURLSchemes</key><array><string>bliss</string></array>
  </dict></array>
</dict>
</plist>
PLIST
fi

# --- Install everything with one sudo block ---
echo "[bliss] install: installing (requires sudo)"
sudo bash -c "
  mkdir -p '${INSTALL_BIN}' '${SHARE_DIR}/quotes' '${SHARE_DIR}/problems'

  cp '${ROOT_DIR}/build/bliss' '${ROOT_DIR}/build/blissd' '${ROOT_DIR}/build/blissroot' '${INSTALL_BIN}/'
  chmod 755 '${INSTALL_BIN}/bliss' '${INSTALL_BIN}/blissd' '${INSTALL_BIN}/blissroot'
  /usr/bin/codesign --force --sign - '${INSTALL_BIN}/bliss' '${INSTALL_BIN}/blissd' '${INSTALL_BIN}/blissroot' >/dev/null 2>&1 || true

  cp '${ROOT_DIR}/quotes/'*.txt '${SHARE_DIR}/quotes/' 2>/dev/null || true
  cp '${ROOT_DIR}/problems/'*.json '${SHARE_DIR}/problems/' 2>/dev/null || true
  cp '${ROOT_DIR}/scripts/uninstall.sh' '${SHARE_DIR}/uninstall.sh'
  chmod 755 '${SHARE_DIR}/uninstall.sh'

  rm -rf /Applications/BlissGUI.app
  cp -R '${GUI_APP_BUNDLE}' /Applications/BlissGUI.app
  /usr/bin/codesign --force --sign - /Applications/BlissGUI.app >/dev/null 2>&1 || true
"

# --- Root helper ---
echo "[bliss] install: root helper"
ROOT_PLIST=""
if [[ -f "${ROOT_DIR}/root/com.bliss.root.plist" ]]; then
  ROOT_PLIST="${ROOT_DIR}/root/com.bliss.root.plist"
elif [[ -f "${ROOT_DIR}/root.plist" ]]; then
  ROOT_PLIST="${ROOT_DIR}/root.plist"
fi
if [[ -z "${ROOT_PLIST}" ]]; then
  echo "[bliss] install: missing com.bliss.root.plist"
else
  sudo cp "${ROOT_PLIST}" /Library/LaunchDaemons/com.bliss.root.plist
  sudo cp "${ROOT_PLIST}" "${SHARE_DIR}/com.bliss.root.plist"
  sudo /bin/launchctl bootout system/com.bliss.root 2>/dev/null || true
  if ! sudo /bin/launchctl bootstrap system /Library/LaunchDaemons/com.bliss.root.plist 2>/dev/null; then
    echo "[bliss] warning: launchd bootstrap failed; try: sudo /bin/launchctl bootstrap system /Library/LaunchDaemons/com.bliss.root.plist"
  fi
  sudo /bin/launchctl kickstart -k system/com.bliss.root 2>/dev/null || true
fi

# --- Menubar ---
echo "[bliss] install: menubar"
bash "${ROOT_DIR}/scripts/install_menubar.sh"

echo "[bliss] install: done"
echo ""
echo "Quickstart"
echo "  1) Configure block list: bliss config website add example.com"
echo "  2) Add apps to block:    bliss config app add"
echo "  3) Add browsers to close: bliss config browser add"
echo "  4) Start a session:      bliss start 45"
echo ""
echo "Notes"
echo "  - Bliss ships with nothing configured by default."
echo "  - Browsers listed in config will be closed on start; save work first."
